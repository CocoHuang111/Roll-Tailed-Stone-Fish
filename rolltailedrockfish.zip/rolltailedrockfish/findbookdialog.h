#ifndef FINDBOOKDIALOG_H
#define FINDBOOKDIALOG_H

#include <QDialog>

class FindbookDialog : public QDialog
{
public:
    FindbookDialog(QWidget *parent = nullptr);
};

#endif // FINDBOOKDIALOG_H
